from .stoi import stoi
from .stoi import stoi_any_fs

__version__ = '0.3.3'
